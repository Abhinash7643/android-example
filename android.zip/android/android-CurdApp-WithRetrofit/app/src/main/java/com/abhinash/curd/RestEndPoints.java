package com.abhinash.curd;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface RestEndPoints {

    @POST("student/addStudentDetails")
    Call<Student> addStudent(@Body Student Student);

    @GET("student/getAll")
    Call<List<Student>>  getAllStudent();

    @DELETE("student/deleteById/{id}")
    Call<List<Student>> deleteById(@Path("id") Long studentId);

}
