package com.abhinash.curd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FormActivity extends AppCompatActivity {
    private TextView name, age, about, studentId;
    private Button button;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        name = findViewById(R.id.name);
        age  = findViewById(R.id.age);
        about = findViewById(R.id.about);
        button  = findViewById(R.id.submitButton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Student student = new Student();
                student.setStudentId(null);
                student.setName(name.getText().toString());
                student.setAge(Integer.parseInt(age.getText().toString()));
                student.setAbout(about.getText().toString());
                SaveStudentDetails(student);

            }

            private void SaveStudentDetails(Student student) {
                RestClint.getPlaceEndPoints().addStudent(student).enqueue(new Callback<Student>() {
                    @Override
                    public void onResponse(Call<Student> call, Response<Student> response) {
                        if (null != response.body()) {
                            name.setText("");
                            age.setText("");
                            about.setText("");
                            setResult(RESULT_OK);
                            finish();
                        }
                    }
                    @Override
                    public void onFailure(Call<Student> call, Throwable t) {
                        Log.e("ERROR: ", t.getMessage());
                        setResult(RESULT_CANCELED);
                        finish();
                    }
                });
            }
        });

    }
}
