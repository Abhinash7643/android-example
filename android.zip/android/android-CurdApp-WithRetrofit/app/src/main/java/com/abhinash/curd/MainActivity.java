package com.abhinash.curd;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
   private RecyclerView mRecyclerView;
  private StudentAdapter studentAdapter;
   private RecyclerView.LayoutManager mLayoutManager;
   private Button button;
   private Context mcontext = this;
    List<Student> studentList = new ArrayList<>();
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getStudentsFromApi();

        button = findViewById(R.id.addButton);
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        studentAdapter = new StudentAdapter(mcontext,studentList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(studentAdapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mcontext, FormActivity.class);
                startActivityForResult(intent, 303);
            }
        });
    }

    private void getStudentsFromApi() {
        RestClint.getPlaceEndPoints().getAllStudent().enqueue(new Callback<List<Student>>() {
            @Override
            public void onResponse(Call<List<Student>> call, Response<List<Student>> response) {
                if(null!= response.body()){
                    studentList.clear();
                    studentList.addAll(response.body());
                    studentAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<Student>> call, Throwable t) {
                Log.d(TAG, "onFailure: "+t.getMessage());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 303 ){
            if(resultCode == RESULT_OK){
                getStudentsFromApi();
                Toast.makeText(this, "Student Details added successfully", Toast.LENGTH_LONG).show();

            } else {
                Toast.makeText(this, "Student Details added failed", Toast.LENGTH_LONG).show();

            }
        }
    }
}
