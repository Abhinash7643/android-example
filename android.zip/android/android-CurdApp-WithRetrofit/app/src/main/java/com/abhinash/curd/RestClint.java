package com.abhinash.curd;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestClint {

    private static final String API_BASE_URL = "http://192.168.0.190:8080/";

    private static <T> T builder(Class<T> endpoint) {
        return new Retrofit.Builder()
                .baseUrl(API_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(endpoint);

    }
    public static RestEndPoints getPlaceEndPoints() {
        return builder(RestEndPoints.class);
    }
}
