package com.abhinash.curd;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {
    private StudentAdapter studentAdapter;
    private List<Student> mStudentList;
    private Context mContext;

    public StudentAdapter(Context context, List<Student> studentList) {
        this.mContext = context;
        this.mStudentList = studentList;
    }

    public static class StudentViewHolder extends RecyclerView.ViewHolder {

        private TextView name, age, about , studentId;
        private RecyclerView recyclerView;
        private Button delButton;

        private StudentViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.activityName);
            age = v.findViewById(R.id.activityAge);
            about = v.findViewById(R.id.activityAbout);
//            recyclerView = v.findViewById(R.id.recyclerView);
            delButton = v.findViewById(R.id.delButton);
        }
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater mLayoutInflater = LayoutInflater.from(mContext);
        view = mLayoutInflater.inflate(R.layout.activity_student_custom_view, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, final int position) {
        final Student student = mStudentList.get(position);
        final Long studentId = student.getStudentId();
        holder.name.setText(student.getName());
        holder.age.setText(String.valueOf(student.getAge()));
        holder.about.setText(student.getAbout());
        holder.delButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RestClint.getPlaceEndPoints().deleteById(studentId).enqueue(new Callback<List<Student>>() {
                    @Override
                    public void onResponse(Call<List<Student>> call, Response<List<Student>> response) {
                        if (null != response.body()) {
                            Toast.makeText(mContext, "Deleted successfully", Toast.LENGTH_LONG).show();
                            mStudentList.remove(position);
                            notifyItemRemoved(position);
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Student>> call, Throwable t) {
                        Toast.makeText(mContext, "Unable To Delete", Toast.LENGTH_LONG).show();
                    }
                });

            }
        });

    }
    @Override
    public int getItemCount() {
        return mStudentList.size();
    }
}
