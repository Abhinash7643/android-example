package com.abhinash.mycurd.rest;

public class Config {

    public static final String API_BASE_URL = "http://192.168.0.192:8080/";
}
