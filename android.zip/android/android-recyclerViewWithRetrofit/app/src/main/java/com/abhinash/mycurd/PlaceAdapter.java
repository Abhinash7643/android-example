package com.abhinash.mycurd;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class PlaceAdapter extends RecyclerView.Adapter<PlaceAdapter.PlaceViewHolder> {
    private List<Place> mPlaceList;
    private Context mContext ;


    //constructor when we create object of example adapter we have to pass array list or item
    public PlaceAdapter(Context mContext, List<Place> places) {
        this.mContext = mContext;
        this.mPlaceList = places;
    }


    @Override
    public PlaceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view ;
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        view = mInflater.inflate(R.layout.place_item,parent,false);
        return new PlaceViewHolder(view);
    }

    public static class PlaceViewHolder extends RecyclerView.ViewHolder {
        //cretaing view holder
        private ImageView mImageView;
        private TextView name;
        private TextView description;
        private CardView cardView;

        private PlaceViewHolder(View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.imageView);
            name = itemView.findViewById(R.id.name);
            description = itemView.findViewById(R.id.desc);
            cardView=itemView.findViewById(R.id.cardId);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceViewHolder holder, final int position) {
        Place currentItem = mPlaceList.get(position);
        holder.name.setText(currentItem.getName());
        holder.description.setText(currentItem.getDescription());
        Glide.with(mContext).load(currentItem.getImage()).into(holder.mImageView);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, PlaceDetailsActivity.class);
                intent.putExtra("Name", mPlaceList.get(position).getName());
                intent.putExtra("Description",mPlaceList.get(position).getDescription());
                intent.putExtra("Image",mPlaceList.get(position).getImage());
                mContext.startActivity(intent);

            }
        });


    }




    @Override
    public int getItemCount() {
        return mPlaceList.size();
    }
}
