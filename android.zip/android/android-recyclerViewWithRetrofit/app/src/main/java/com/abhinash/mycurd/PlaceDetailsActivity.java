package com.abhinash.mycurd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class PlaceDetailsActivity extends AppCompatActivity {
    private ImageView image;
    private TextView name;
    private TextView description;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_details);

        image = findViewById(R.id.placeImage);
        name  = findViewById(R.id.name);
        description = findViewById(R.id.desc);

        String mName =  getIntent().getStringExtra("Name");
        String mDescription = getIntent().getStringExtra("Description");
        String mImage = getIntent().getStringExtra("Image");

        name.setText(mName);
        description.setText(mDescription);
        Glide.with(this).load(mImage).into(image);

    }
}
