package com.abhinash.mycurd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.abhinash.mycurd.rest.RestClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private TextView textViewResult;

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private PlaceAdapter placeAdapter;
    List<Place> placesList = new ArrayList<>();
    private static final String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//abstracted in to RestClient
//        Retrofit retrofit = new Retrofit.Builder()
//                .baseUrl("http://192.168.0.190:8080/")
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
//
//        PlaceEndPoints placeEndPoints = retrofit.create(PlaceEndPoints.class);
//        Call<List<Place>> call = placeEndPoints.getPlace();

        RestClient.getPlaceEndPoints().getPlace().enqueue(new Callback<List<Place>>() {
            @Override
            public void onResponse(Call<List<Place>> call, Response<List<Place>> response) {
                if(null!= response.body()){
                    placesList.addAll(response.body());
                    placeAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<Place>> call, Throwable t) {
                Log.d(TAG, "onFailure: "+t.getMessage());
            }
        });
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        placeAdapter = new PlaceAdapter(this,placesList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(placeAdapter);
    }

//    private void getPlaces() {
//        RestClient.getPlaceEndPoints().getPlace().enqueue(new Callback<List<Place>>() {
//            @Override
//            public void onResponse(Call<List<Place>> call, Response<List<Place>> response) {
//                if(null!= response.body()){
//                    placesList.addAll(response.body());
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<Place>> call, Throwable t) {
//
//            }
//        });
//    }

}
