package com.abhinash.mycurd.rest;

import com.abhinash.mycurd.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PostEndPoints {

    @GET("place/getAllPlaces")//posts is relative url
    Call<List<Post>> getPosts();
}
